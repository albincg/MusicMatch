"use client";
import { useState } from "react";
import { signIn, useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Music, Play, Users, PlusCircle } from "lucide-react";
import { db } from "@/lib/firebase";
import { doc, setDoc, collection, getDoc } from "firebase/firestore";
import { nanoid } from "nanoid";

export default function Home() {
  const { data: session } = useSession();
  const router = useRouter();
  const [roomCode, setRoomCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [playerName, setPlayerName] = useState("");

  const createRoom = async () => {
    if (!session) return signIn("spotify");
    setLoading(true);
    const id = nanoid(6).toUpperCase();
    try {
      await setDoc(doc(db, "rooms", id), {
        hostId: session.user.email,
        hostName: session.user.name,
        status: "waiting",
        createdAt: Date.now(),
        players: [{ name: session.user.name, id: "host", score: 0 }],
        currentRound: 0,
      });
      router.push(`/room/${id}`);
    } catch (e) {
      console.error(e);
      setLoading(false);
    }
  };

  const joinRoom = async (e) => {
    e.preventDefault();
    if (!roomCode || !playerName) return alert("Please enter name and code");
    setLoading(true);
    const roomRef = doc(db, "rooms", roomCode.toUpperCase());
    const snap = await getDoc(roomRef);
    
    if (snap.exists()) {
      router.push(`/room/${roomCode.toUpperCase()}?player=${encodeURIComponent(playerName)}`);
    } else {
      alert("Room not found!");
      setLoading(false);
    }
  };

  return (
    <main className="flex flex-col items-center justify-center min-h-screen p-4">
      <div className="max-w-md w-full text-center space-y-8">
        <div className="flex flex-col items-center gap-4">
          <div className="bg-[#1DB954] p-4 rounded-full shadow-[0_0_30px_rgba(29,185,84,0.3)]">
            <Music size={48} className="text-black" />
          </div>
          <h1 className="text-5xl font-black tracking-tighter">
            GUESS <span className="text-[#1DB954]">WHO</span>
          </h1>
          <p className="text-zinc-400 font-medium">The social Spotify party game</p>
        </div>

        <div className="glass-card space-y-6">
          {!session ? (
            <button onClick={() => signIn("spotify")} className="spotify-button w-full">
              <Play size={20} fill="currentColor" />
              Host a Game
            </button>
          ) : (
            <button onClick={createRoom} disabled={loading} className="spotify-button w-full">
              <PlusCircle size={20} />
              {loading ? "Creating..." : "Create New Lobby"}
            </button>
          )}

          <div className="relative">
            <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-zinc-800"></span></div>
            <div className="relative flex justify-center text-xs uppercase"><span className="bg-zinc-900 px-2 text-zinc-500">Or Join One</span></div>
          </div>

          <form onSubmit={joinRoom} className="space-y-3">
            <input
              type="text"
              placeholder="Your Name"
              className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-[#1DB954] transition-all"
              value={playerName}
              onChange={(e) => setPlayerName(e.target.value)}
            />
            <input
              type="text"
              placeholder="6-Digit Room Code"
              className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-[#1DB954] transition-all uppercase text-center tracking-[0.5em] font-mono"
              maxLength={6}
              value={roomCode}
              onChange={(e) => setRoomCode(e.target.value)}
            />
            <button 
              type="submit" 
              disabled={loading}
              className="w-full bg-white text-black font-bold py-3 rounded-xl hover:bg-zinc-200 transition-all flex items-center justify-center gap-2"
            >
              <Users size={20} />
              Join Party
            </button>
          </form>
        </div>
      </div>
    </main>
  );
}
